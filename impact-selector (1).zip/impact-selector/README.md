# Change-Impact Test Selector (with transparent skip rationale)

For an online exam platform facing odd student behaviour and weak networks: **which tests can be safely skipped for this change – and why?**
Stdlib-only Python 3.10+ (matplotlib optional for plots). ~75% milestone: see `docs/STATUS.md`.

**Headline (synthetic data, held-out 800 commits):** suite time **−60.6%**, recall of affected tests **99.92%** (6 of 7,860 missed) vs run-all (0% / 100%) and name-match baseline (−94.5% / 32% recall).
Under 50% delayed + 30% duplicated + reordered events the final state is **bit-identical** to the clean run; crash recovery from a torn log is identical too.

```bash
python scripts/generate_data.py            # optional: data/ is already generated (seed 42)
python -m unittest discover -s tests       # 20 tests
python experiments/run_experiment.py       # ~90 s -> experiments/results/{results.md,metrics.json,*.png}
python -m selector.cli --files core/timer.py --show-skipped
python app/server.py                       # web UI + API on http://localhost:8000
```

| Path | What |
|---|---|
| `selector/engine.py` | modes `all`, `name_match`, `graph`, `coverage`, `hybrid`; guards; per-test reasons |
| `selector/events.py` | idempotent, order-insensitive, crash-recoverable event store |
| `selector/sim.py` | replay harness + fault-injecting channel |
| `app/` , `selector/cli.py` | functional application (UI/API/CLI) |
| `scripts/generate_data.py`, `data/` | data generation and generated data |
| `experiments/` | experiment script, notebook, results |
| `docs/` | technical doc, failure-mode analysis, workflow map, user-feedback kit, presentation outline, status |
| `tests/` | logic + failure-state tests |

**Read `docs/technical.md` §8 (limitations) before quoting the numbers**: data is synthetic, and production use needs periodic full-suite audit runs to feed the history signal.
