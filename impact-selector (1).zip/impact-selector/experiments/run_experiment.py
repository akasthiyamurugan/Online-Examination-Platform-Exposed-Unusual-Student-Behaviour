#!/usr/bin/env python3
"""Runs every experiment and writes experiments/results/{metrics.json,results.md,*.png}.
Usage:  python experiments/run_experiment.py
Split (walk-forward, history is learned online):  0-1199 warm-up | 1200-1599 validation (tune tau) | 1600-2399 held-out test
"""
import json, os, sys, time, random, collections
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from selector.data import Dataset
from selector.engine import ImpactSelector, Config
from selector.events import EventStore
from selector.sim import simulate, summarise, perturb, OVERHEAD

VAL, TEST = (1200, 1600), (1600, 2400)
TARGET = dict(recall_pct=99.5, time_reduction_pct=50.0)
OUT = os.path.join(os.path.dirname(__file__), "results")
os.makedirs(OUT, exist_ok=True)
ds = Dataset(os.path.join(os.path.dirname(__file__), "..", "data"))
M = {}

def row(name, recs, lo=TEST[0], hi=TEST[1]):
    s = summarise(recs, ds, lo, hi); s["name"] = name; return s

# ---------------------------------------------------------------- 1. tune tau on validation only
sweep = []
for tau in [0.03, 0.05, 0.08, 0.12, 0.2, 0.3, 0.5]:
    r, _, _ = simulate(ds, "hybrid", Config(tau=tau))
    s = summarise(r, ds, *VAL); s["tau"] = tau; sweep.append(s)
ok = [s for s in sweep if s["recall_pct"] >= 99.9]
best_tau = max(ok, key=lambda s: s["time_reduction_pct"])["tau"] if ok else max(sweep, key=lambda s: s["recall_pct"])["tau"]
M["tau_sweep_validation"], M["chosen_tau"] = sweep, best_tau
cfg = Config(tau=best_tau)

# ---------------------------------------------------------------- 2. baselines vs approaches (held-out test)
runs = {}
table = []
for name, mode, c in [("Baseline 1: run everything", "all", None), ("Baseline 2: name match", "name_match", None),
                      ("Approach A: dependency graph", "graph", None), ("Approach B: coverage map", "coverage", None),
                      ("Ablation: graph+coverage (no history)", "hybrid", Config(tau=1e9)),
                      ("Approach C: hybrid (selected)", "hybrid", cfg)]:
    r, st, _ = simulate(ds, mode, c); runs[name] = r; table.append(row(name, r))
M["comparison_test"] = table
hyb = runs["Approach C: hybrid (selected)"]
M["hybrid_by_commit_type"] = {}
for ct in sorted({x["type"] for x in hyb[TEST[0]:TEST[1]]}):
    sub = [x for x in hyb[TEST[0]:TEST[1]] if x["type"] == ct]
    full = ds.suite_time + OVERHEAD
    F = sum(x["failed"] for x in sub); C = sum(x["caught"] for x in sub)
    M["hybrid_by_commit_type"][ct] = dict(commits=len(sub), time_reduction_pct=round(100 * (1 - sum(x["time"] for x in sub) / (full * len(sub))), 1),
                                           recall_pct=round(100 * C / F, 2) if F else 100.0, missed=F - C)

# ---------------------------------------------------------------- 3. robustness / fault injection
rob = []
def rob_row(name, recs, extra=None):
    s = row(name, recs); s.update(extra or {}); rob.append(s); return s

rob_row("Clean (reference)", hyb)
g30, e30 = perturb(ds, cov_drop=.30)
r, _, _ = simulate(ds, "hybrid", cfg, init_cov=e30, refresh=False); rob_row("Stale coverage: 30% entries dropped, no refresh", r)
g25, _ = perturb(ds, edge_drop=.25)
r, _, _ = simulate(ds, "hybrid", cfg, graph=g25); rob_row("Dependency map: 25% of edges missing", r)
g, e = perturb(ds, cov_drop=.30, edge_drop=.25)
r, _, _ = simulate(ds, "hybrid", cfg, graph=g, init_cov=e, refresh=False); rob_row("Both degraded (map -25% edges, coverage -30%)", r)

clean_r, clean_store, _ = simulate(ds, "hybrid", cfg)
r, st, ch = simulate(ds, "hybrid", cfg, chaos=dict(p_delay=.5, delay_max=15, p_dup=.3))
ev_rows = []
rob_row("Events: 50% delayed<=15 commits (out-of-order) + 30% duplicated", r,
        dict(state_hash_equals_clean=st.state_hash() == clean_store.state_hash(), event_counts=st.counts))
LOSS = dict(p_delay=.5, delay_max=15, p_dup=.3, p_drop=.03)
for label, kw in [("Events: as above + 3% permanently LOST (gap fail-safe, auto-skip after 200 events)", dict(gap_tolerance=25, auto_skip=200)),
                  ("Events: 3% LOST (gap fail-safe, auto-skip after 60 events)", dict(gap_tolerance=25, auto_skip=60)),
                  ("Events: 3% LOST, fail-safe DISABLED (for contrast)", dict(gap_tolerance=10**9, auto_skip=10**9))]:
    r, st2, ch2 = simulate(ds, "hybrid", cfg, chaos=LOSS, store_kw=kw)
    rob_row(label, r, dict(lost_events=len(ch2.dropped), skipped_gaps=len(st2.skipped), event_counts=st2.counts, state_hash_equals_clean="n/a (events lost; gaps recorded)"))
M["robustness"] = rob

# crash / torn-write recovery
logp = os.path.join(OUT, "_crash.jsonl")
if os.path.exists(logp): os.remove(logp)
_, live, _ = simulate(ds, "hybrid", cfg, log_path=logp, chaos=dict(p_delay=.5, delay_max=15, p_dup=.3))
live._log.close(); h_live = live.state_hash()
data = open(logp).read()
open(logp, "w").write(data + '{"event_id": "ci-torn", "stream": "ci", "seq": 99')   # simulate power loss mid-write
rec = EventStore.recover(logp)
M["crash_recovery"] = dict(hash_before_crash=h_live, hash_after_recovery=rec.state_hash(), identical=h_live == rec.state_hash(),
                           log_lines=data.count("\n"))
os.remove(logp)

# ---------------------------------------------------------------- 4. error analysis (held-out test, chosen design)
truth = ds.truth
miss_rows = []
for x in hyb[TEST[0]:TEST[1]]:
    c = ds.commits[x["idx"]]
    for t in x["missed"]:
        tg, hd, td = set(ds.tests[t]["targets"]), set(truth["hidden"][t]), set(truth["true_deps"][t])
        rel = ["hidden runtime edge" if set(c["files"]) & hd else "transitive dep missing from map+coverage" if set(c["files"]) & td else "not linked to changed files"]
        miss_rows.append(dict(commit=c["id"], test=t, test_type=ds.tests[t]["type"], change_type=c["change_type"], files=c["files"], cause=rel[0]))
M["missed_tests_hybrid"] = miss_rows
# what dominates remaining runtime?
tt = collections.Counter(); n = 0
sel_all = ImpactSelector(ds.graph, ds.tests, clean_store, cfg)
for x in ds.commits[TEST[0]:TEST[1]:8]:
    d = sel_all.select(x["files"], x["ast_unchanged"], "hybrid"); n += 1
    for rr in d.rows:
        if rr["run"]: tt[rr["type"]] += rr["duration"]
M["runtime_share_by_type_pct"] = {k: round(100 * v / sum(tt.values()), 1) for k, v in tt.items()}
# false-alarm anatomy: selected but did not fail (cost of safety)
# latency
t0 = time.perf_counter()
for x in ds.commits[TEST[0]:TEST[0] + 200]: sel_all.select(x["files"], x["ast_unchanged"], "hybrid")
M["decision_latency_ms"] = round(1000 * (time.perf_counter() - t0) / 200, 2)

# ---------------------------------------------------------------- 5. verdict vs target
h = row("hybrid", hyb)
M["target"] = TARGET
M["measured"] = {k: h[k] for k in ("recall_pct", "time_reduction_pct", "missed_tests", "affected_tests", "commits_fully_safe_pct")}
M["met"] = {"recall": h["recall_pct"] >= TARGET["recall_pct"], "time": h["time_reduction_pct"] >= TARGET["time_reduction_pct"]}
json.dump(M, open(os.path.join(OUT, "metrics.json"), "w"), indent=1)

# ---------------------------------------------------------------- markdown report
L = ["# Experiment results (auto-generated by experiments/run_experiment.py)\n",
     f"Chosen tau (max time saving on validation subject to recall >= 99.9%): **{best_tau}**\n",
     f"Held-out test window: commits {TEST[0]}-{TEST[1]-1}. Full suite = {ds.suite_time:.0f}s + {OVERHEAD:.0f}s fixed overhead.\n",
     "## 1. Baselines vs approaches (held-out)\n", "| Design | Time reduction | Recall of affected tests | Missed / affected | Commits with zero misses | Avg tests run |", "|---|---|---|---|---|---|"]
for s in table:
    L.append(f"| {s['name']} | {s['time_reduction_pct']}% | {s['recall_pct']}% | {s['missed_tests']} / {s['affected_tests']} | {s['commits_fully_safe_pct']}% | {s['avg_tests_run']} |")
L += ["\n## 2. Tau sweep (validation)\n", "| tau | time reduction | recall | missed |", "|---|---|---|---|"]
L += [f"| {s['tau']} | {s['time_reduction_pct']}% | {s['recall_pct']}% | {s['missed_tests']} |" for s in sweep]
L += ["\n## 3. Fault injection (held-out, hybrid)\n", "| Scenario | Time reduction | Recall | Missed | State == clean run |", "|---|---|---|---|---|"]
for s in rob:
    L.append(f"| {s['name']} | {s['time_reduction_pct']}% | {s['recall_pct']}% | {s['missed_tests']} | {s.get('state_hash_equals_clean','n/a')} |")
L += [f"\nCrash recovery (torn final log line): identical state = **{M['crash_recovery']['identical']}** ({M['crash_recovery']['hash_after_recovery']})\n",
      "## 4. Hybrid by commit type (held-out)\n", "| Type | Commits | Time reduction | Recall | Missed |", "|---|---|---|---|---|"]
L += [f"| {k} | {v['commits']} | {v['time_reduction_pct']}% | {v['recall_pct']}% | {v['missed']} |" for k, v in M["hybrid_by_commit_type"].items()]
L += ["\n## 5. Error analysis - missed tests (hybrid, held-out)\n", "| Commit | Test | Test type | Change type | Cause |", "|---|---|---|---|---|"]
L += [f"| {m['commit']} | {m['test']} | {m['test_type']} | {m['change_type']} | {m['cause']} |" for m in miss_rows] or ["| (none) | | | | |"]
L += [f"\nRuntime share of what still runs, by test type: {M['runtime_share_by_type_pct']}", f"\nDecision latency: {M['decision_latency_ms']} ms/commit",
      f"\n## Target vs measured\nTarget: recall >= {TARGET['recall_pct']}% and time reduction >= {TARGET['time_reduction_pct']}%. Measured: recall {h['recall_pct']}%, time reduction {h['time_reduction_pct']}% -> met: {M['met']}"]
open(os.path.join(OUT, "results.md"), "w").write("\n".join(L) + "\n")

# ---------------------------------------------------------------- plots
try:
    import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
    fig, ax = plt.subplots(figsize=(7, 4.5))
    for s in table:
        ax.scatter(s["time_reduction_pct"], s["recall_pct"], s=70); ax.annotate(s["name"].split(":")[0] + (": " + s["name"].split(": ")[1][:14] if ":" in s["name"] else ""), (s["time_reduction_pct"], s["recall_pct"]), fontsize=7, xytext=(4, 4), textcoords="offset points")
    ax.axhline(TARGET["recall_pct"], ls="--", c="gray"); ax.axvline(TARGET["time_reduction_pct"], ls="--", c="gray")
    ax.set_xlabel("Suite time reduction (%)"); ax.set_ylabel("Recall of affected tests (%)"); ax.set_title("Safety vs speed (held-out commits); dashed = target")
    ax.set_ylim(min(30, 100), 101); fig.tight_layout(); fig.savefig(os.path.join(OUT, "tradeoff.png"), dpi=140)
    fig, ax = plt.subplots(figsize=(6, 4))
    ax.plot([s["tau"] for s in sweep], [s["time_reduction_pct"] for s in sweep], "o-", label="time reduction %")
    ax.plot([s["tau"] for s in sweep], [s["recall_pct"] for s in sweep], "s-", label="recall %")
    ax.set_xscale("log"); ax.set_xlabel("tau (history threshold)"); ax.legend(); ax.set_title("Validation sweep"); fig.tight_layout(); fig.savefig(os.path.join(OUT, "tau_sweep.png"), dpi=140)
except Exception as e:
    print("plots skipped:", e)
print(open(os.path.join(OUT, "results.md")).read())
