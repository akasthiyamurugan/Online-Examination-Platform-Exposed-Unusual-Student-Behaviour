# Presentation outline (convert to slides – 10 slides, ~10 min)

1. **Problem** – exam platform, weak networks + odd student behaviour → big suite → nobody knows what's safe to skip. Cost: ~100 min/run.
2. **Field workflow map** – (docs/workflow_map.md diagram) where changes come from and where the selector sits.
3. **Goal & target** – recall of affected tests ≥ 99.5%, time saved ≥ 50%; every skip explainable.
4. **Data** – 72 modules, 320 tests, 2,400 commits; deliberately imperfect map/coverage; hidden edges. *Synthetic – say so.*
5. **Two approaches + hybrid** – A graph, B coverage, C union + history + guards; decision table.
6. **Live demo** – `core/autosave.py` (RUN/SKIP with reasons), `docs/faq.md` (smoke only), unknown file (widen).
7. **Result** – tradeoff.png; table: baseline / A / B / C. 60.6% saved at 99.92% recall.
8. **Failure injection** – delayed/duplicated/out-of-order → identical state hash; lost events → fail-safe; crash recovery; where it breaks (94.5% when both inputs are degraded).
9. **Error analysis & limits** – 6 misses explained; synthetic data; needs audit runs; e2e still 55% of runtime.
10. **Stakeholder validation & next steps** – findings from sessions (once run); roadmap in docs/STATUS.md.
