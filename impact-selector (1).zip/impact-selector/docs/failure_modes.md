# Failure-mode analysis

Each row: what goes wrong → what the system does → evidence (test / experiment) → residual risk.

| # | Failure state | Behaviour | Evidence | Residual risk |
|---|---|---|---|---|
| F1 | **Duplicate events** (client/CI retries; at-least-once delivery) | ignored by `event_id`; state unchanged | `test_duplicates_are_idempotent`; 934 duplicates absorbed in chaos run; hash == clean | none known |
| F2 | **Out-of-order events** | per-stream sequence numbers; later events buffered until predecessors arrive, then applied in order; competing writes resolved by `(version/revision, canonical JSON)` so arrival order cannot matter | `test_out_of_order_converges` (20 shuffles); chaos hash == clean | selector uses slightly older history while buffered |
| F3 | **Delayed events** (weak network) | buffered; nothing after the gap is applied (no partial state); heals on arrival | `test_delay_buffers_then_applies…` | short-lived lag only |
| F4 | **Stale coverage arrives after fresh** | version comparison – stale never overwrites | `test_stale_coverage_never_overwrites_newer` | – |
| F5 | **Same seq, different event id** (buggy producer) | rejected as `conflict`, logged, never overwrites | `test_conflicting_seq_rejected` | producer must be fixed; count exposed in `/api/health` |
| F6 | **Permanently lost event** | gap older than `gap_tolerance` → *degraded*: selector runs all non-unit tests; after `auto_skip` events the gap is skipped **and recorded** in state | `test_lost_event_degrades…`; 3% loss run: recall 99.92–99.95% (vs 99.69% fail-safe off) | costs time: saving falls to 27–38% while degraded → tune `auto_skip`; alert on `/api/health` |
| F7 | **Crash / torn write** | append-only log; recovery drops a partially written tail line and replays | `test_torn_write_recovery`; experiment: identical hash | events after the torn line are lost (producers must re-send; dedup makes that safe) |
| F8 | **Stale / incomplete coverage** | graph + history still select; unmeasured tests always run | 30% dropped: recall 99.11% | recall below target if coverage is very stale *and* map is bad (F9) |
| F9 | **Incomplete dependency map** (dynamic imports) | coverage + history compensate | 25% edges missing: 99.54%; both degraded: **94.48% (below target)** | needs input-quality monitoring (edge/coverage age) – next step |
| F10 | **Docs / formatting-only change** | smoke only, reason "no executable change" | 98.8% saved, 0 misses | relies on correct AST-equality check upstream |
| F11 | **Unknown file** (new module) | runs all non-unit tests | `test_unknown_file_runs_all_non_unit` | low saving (3%) on new-file commits |
| F12 | **Config change** | runs everything | `test_config_change_runs_everything` | zero saving; candidate for finer config→test mapping |
| F13 | **Empty change set** | smoke only, noted | `test_empty_change_set` | an empty diff could mean a lost webhook – verify at the caller |
| F14 | **New / unmeasured test** | never skipped until a coverage record arrives | `test_unmeasured_test_is_never_skipped` | ~10% of tests always run early on |
| F15 | **Hidden runtime edge nobody has seen fail** | can be missed (cold start of history) | held-out misses: 4 repeats of one unit test with a dropped edge, 1 hidden-edge unit test, 1 e2e test | mitigate with scheduled full audit runs + faster learning after a miss |
| F16 | **Flaky test** | failures recorded separately, excluded from associations | generator | real flake detection not built |
