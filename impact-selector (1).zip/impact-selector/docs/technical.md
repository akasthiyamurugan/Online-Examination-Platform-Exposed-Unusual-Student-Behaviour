# Technical documentation

## 1. Problem and stakeholder
An online examination platform sees **unusual student behaviour** (tab-switching, double submits, reconnect storms, paste/idle patterns) and **weak networks** (drops mid-answer, high latency, duplicated/out-of-order client events). That justifies a large test suite (unit, integration, e2e, network-fault). The engineering lead cannot tell **which tests are safe to skip for a low-risk change**, so every change pays for the full suite (~100 min here) or teams skip by gut feel.

**Intervention:** a change-impact test selector that, for every change, returns *run / skip per test with a human-readable reason*, and is measured on **time saved** vs **affected tests missed**.

## 2. Data and the (synthetic) failure model
`scripts/generate_data.py` (seed 42) creates a 72-module layered exam platform (utils → core → net → services → proctor → ui), 320 tests, and 2,400 commits.

| Artefact | What it represents | Deliberate imperfection |
|---|---|---|
| `dependency_map.json` | static import graph | 6% of edges missing (dynamic imports, reflection) |
| `coverage.json` | coverage snapshot v1 | 8% of entries dropped; 30 tests (~10%) have no record (new tests) |
| `tests.json` | id, type, duration, declared targets | unit tests only depend 1 hop deep; integration/e2e 3 hops |
| `commits.json` | files, change type, `ast_unchanged`, failing tests | includes docs, style-only (AST identical), config, new-file commits |
| `ground_truth/true_deps.json` | runtime truth | 15% of tests have 1-2 **hidden** runtime edges (feature flags, shared fixtures) |

**Why a test fails after a change** (this is the simulator's assumption, and the main threat to validity): for a code-changing commit, P(fail) per changed file is 0.50 / 0.22 / 0.35 (logic) or 0.12 / 0.05 / 0.08 (refactor) when the file is the test's *direct target* / a *transitive dependency* / a *hidden edge*; 0 otherwise. Config commits fail e2e/network tests with p=0.3 (integration 0.1). New-file commits fail non-unit tests at ~1.2% plus direct targets. Style/docs commits never fail. Flaky failures are recorded separately and excluded from ground truth.

## 3. Approaches compared

| | A. Static dependency graph | B. Coverage map | **C. Hybrid (selected)** | D. Learned ranker (considered) |
|---|---|---|---|---|
| Signal | reverse-import closure ∩ test targets | test's recorded coverage ∋ changed file | A ∪ B ∪ history co-failure association + guards | model P(fail \| features) |
| Sees dynamic/hidden edges | ✗ | ✓ (if coverage fresh) | ✓ (coverage + history) | ✓ |
| Fresh for new tests | ✓ | ✗ (unrecorded → must run) | ✓ / run-if-unknown | ✗ cold start |
| Stale-data risk | map drift | coverage drift | must fail on *all* signals to skip | drift + opaque |
| Explainable skip reason | ✓ | ✓ | ✓ (one reason per signal) | ✗ needs post-hoc explainer |
| Extra infra | import parser | coverage per test | + event store | + training pipeline, MLOps |

**Decision.** C. Measured (held-out): A misses 4.3% and B 1.5% of affected tests *at equal ~62% time saving*; their blind spots differ, so a test is skipped only if **every** signal independently says skip. On this data history adds only a marginal gain (99.90% → 99.92%, 8 → 6 misses); its value under drifting inputs was **not** separately measured (ablation under degraded inputs is a listed next step). D was rejected for a decision-maker use-case: it cannot state *why* a test is skipped, needs labelled data we do not have on day 1, and a mis-ranked skip in exam-critical code (timer, submission, autosave) is costlier than the extra time saved. It is the natural v2 once the audit-run labels accumulate (STATUS.md).

## 4. Architecture
```
git diff ─► files + ast_unchanged ─┐
dependency_map ────────────────────┤        ┌── GUARDS: docs/AST-identical → smoke only;
EventStore (coverage, CI outcomes) ┼► ImpactSelector ─┤  config → run all; unknown file → all non-unit;
                                   │        │         │  degraded feed → all non-unit; smoke always
 CLI / web app / HTTP API ◄────────┘        └── SIGNALS: GRAPH · COVERAGE · HISTORY → per-test rationale
        ▲                                   
 CI outcomes + coverage refresh ──(delayed/duplicated/out-of-order)──► EventStore
```
* `selector/engine.py` – decision logic and rationale. `selector/events.py` – event-sourced state. `selector/sim.py` – replay harness + fault injector (`Channel`). `app/server.py` – stdlib HTTP API + UI. `selector/cli.py` – CLI.
* **Skip rationale.** Every test row carries reasons. RUN rows name the first triggering signal (`GRAPH: target X depends transitively on an edited file`, `COVERAGE: v31 shows it executes X`, `HISTORY: failed in 12 of last 35 changes to X (34%)`, or a `GUARD`). SKIP rows list **why each active signal said no** with numbers (`no import path…`, `coverage v45 (6 modules) has none of the edited files`, `max co-failure 8.6% (n=35) < tau 30%`). Nothing is skipped without a stored explanation.
* **History signal.** score(f,t) = failures of t in past code-changing commits touching f ÷ past changes of f; used only if the file has ≥3 past changes (`min_support`); threshold `tau` picked on a validation window (§5).

## 5. Evaluation protocol
Walk-forward replay of 2,400 commits (history learned online, outcomes fed back as events): 0–1199 warm-up, 1200–1599 validation (tune `tau`: maximise time saved subject to recall ≥ 99.9%), 1600–2399 **held-out test**. Coverage is refreshed for 16 tests every 50 commits (nightly-job analogue). Time = 30 s fixed overhead + Σ durations of selected tests.
**Target:** recall of affected tests ≥ 99.5% *and* time reduction ≥ 50%. Full tables: `experiments/results/results.md`.

## 6. Results (held-out, 800 commits, 7,860 affected-test occurrences)
| Design | Time reduction | Recall | Missed | Commits with zero misses |
|---|---|---|---|---|
| Run everything (baseline 1) | 0% | 100% | 0 | 100% |
| Name match (baseline 2) | 94.5% | 32.0% | 5,344 | 38.4% |
| A graph | 61.8% | 95.7% | 337 | 79.8% |
| B coverage | 61.8% | 98.5% | 115 | 88.8% |
| graph+coverage (no history) | 60.8% | 99.90% | 8 | 99.0% |
| **C hybrid** | **60.6%** | **99.92%** | **6** | **99.2%** |

**Target vs measured:** recall ≥99.5% → 99.92% ✓; time ≥50% → 60.6% ✓ (≈ 5,967 s → 2,350 s average per commit). By commit type: docs/style −98.8%, logic/refactor ≈ −62–63%, new-file −3.1%, config 0% (both deliberately conservative).
**Error analysis (6 misses):** 4 are the same unit test (`unit_288`) whose dependency is missing from **both** the static map and its coverage record; history needs ≥3 observations before it protects a test, so it kept slipping through. 1 is a unit test with a *hidden runtime edge* (`unit_085`), 1 is an e2e test (`e2e_294`) with a dropped edge. All 6 are low-cost or single-occurrence, but `e2e_294` shows exam-level tests are not immune. Remaining runtime is 55% e2e, 21% network-fault, 20% integration – that is where further savings must come from.

## 7. Robustness / failure injection (held-out)
| Scenario | Time red. | Recall | Result |
|---|---|---|---|
| 30% coverage dropped, no refresh | 57.5% | 99.11% | degrades gracefully; graph+history still cover |
| 25% dependency edges missing | 61.2% | 99.54% | still ≥ target |
| both degraded | 59.7% | 94.48% | **below target** – documented limit; monitor input quality |
| 50% events delayed ≤15 commits (out-of-order) + 30% duplicated | 59.7% | 99.92% | **final state hash identical to clean run** |
| + 3% events permanently lost, auto-skip after 200 / 60 events | 27.1% / 37.7% | 99.92% / 99.95% | fail-safe widens selection; gap recorded; vs 99.69% with fail-safe off |
| crash with torn final log line | – | – | recovered state hash identical |

## 8. Limitations / threats to validity (read before quoting numbers)
1. **Synthetic data.** Numbers validate the *design* and the mechanisms, not a forecast for your repo. The failure model in §2 was written by us; real failure structure may be less separable.
2. **Outcome feed assumes an audit run.** History and misses are only observable when skipped tests are *also* executed somewhere (nightly/post-merge full run or sampled shadow runs). The simulator supplies ground truth for every test. In production this needs a scheduled full-suite audit; otherwise the history signal starves.
3. `tau` tuned on one validation window and one seed; no confidence intervals yet.
4. Selector reads file-level changes; no function-level diffing. Config and new-file changes are handled conservatively (≈0–3% saving).
5. Multi-file commits attribute failures to every changed file (noisy associations).
6. The user-validation section (docs/user_feedback.md) is a protocol + template; no real stakeholder sessions have been run yet.

## 9. Run it
```bash
python scripts/generate_data.py                    # regenerate data (deterministic)
python -m unittest discover -s tests               # 20 tests: logic + event faults
python experiments/run_experiment.py               # ~90 s, writes experiments/results/
python -m selector.cli --files core/timer.py --show-skipped
python app/server.py                               # http://localhost:8000
```
