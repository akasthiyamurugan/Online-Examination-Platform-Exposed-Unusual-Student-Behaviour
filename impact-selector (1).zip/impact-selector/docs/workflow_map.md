# Field-workflow map

```mermaid
flowchart LR
  subgraph Field["Exam day (field)"]
    S[Student behaviour: tab switch, double submit, reconnect storm, idle/paste] --> X[Incident / bug report]
    N[Weak network: drops, latency, duplicate & out-of-order client events] --> X
  end
  X --> D[Developer fixes / changes code]
  D --> PR[Pull request: changed files + AST-identical flag]
  PR --> SEL{{Impact selector}}
  DEP[(Dependency map)] --> SEL
  ES[(Event store: coverage + past CI outcomes)] --> SEL
  SEL -->|RUN list + reason| CI[CI runs selected tests]
  SEL -->|SKIP list + reason| REV[Reviewer / lead can audit every skip]
  CI --> OUT[CI outcome event]
  AUD[Scheduled full-suite audit] --> OUT
  COV[Coverage refresh job] --> CE[Coverage event]
  OUT -- delayed / duplicated / out-of-order --> ES
  CE -- delayed / duplicated / out-of-order --> ES
  ES -->|health: degraded?| SEL
  CI --> REL[Release to exam platform]
```

## Where field behaviour maps to tests
| Field condition | Test family | Modules that should always pull these tests in |
|---|---|---|
| Connection drops mid-answer | `network_fault` | `net/sync`, `net/offline_queue`, `core/autosave` |
| Reconnect storm / duplicate submit | `integration`, `network_fault` | `core/submission`, `net/conflict_resolver`, `core/attempt_state` |
| Clock skew / deadline edge | `unit`, `e2e` | `core/timer`, `core/deadline`, `utils/clock` |
| Tab-switch / paste / idle flags | `integration` | `proctor/*` |
| Low-end device UI | `e2e` | `ui/*` |

## Change-risk tiers used by the selector
| Tier | Example | Policy |
|---|---|---|
| 0 – no executable change | docs, formatting (AST identical) | smoke only |
| 1 – code change with bounded impact | edit in known module | GRAPH ∪ COVERAGE ∪ HISTORY |
| 2 – unbounded impact | new file, config, degraded evidence | widen (all non-unit / all) |
