# Project status – ~75% complete

## Done (in this repo)
- [x] Field-workflow map (docs/workflow_map.md)
- [x] Data-generation script (scripts/generate_data.py) + generated data
- [x] Core logic: 2 baselines, 2 single-signal approaches, hybrid with guards (selector/engine.py)
- [x] Transparent skip rationale for every test (RUN and SKIP)
- [x] Event-sourced state store with dedup / reordering / gap handling / crash recovery (selector/events.py)
- [x] Functional application: CLI + web UI + HTTP API (app/, selector/cli.py)
- [x] Measurable experiment: walk-forward, validation-tuned, held-out, target vs measured, error analysis (experiments/run_experiment.py, results/)
- [x] Failure injection: delayed, duplicated, out-of-order, lost events, torn write, stale coverage, missing edges, unknown/config/docs/empty changes
- [x] 20 automated tests (`python -m unittest discover -s tests`), CI workflow
- [x] Experiment notebook (experiments/experiment.ipynb) – code verified; outputs not saved
- [x] Technical documentation, failure-mode analysis, presentation outline

## Remaining (~25%)
- [ ] **Run the 3 stakeholder sessions** and fill docs/user_feedback.md (currently a template – do not claim feedback you don't have)
- [ ] Turn docs/presentation_outline.md into an actual slide deck (embed tradeoff.png, UI screenshots)
- [ ] Execute the notebook in Jupyter and commit it with outputs; take UI screenshots
- [ ] Real-repo adapters: `git diff --name-only` → files; `coverage.py` contexts → coverage events; AST-equality check for `ast_unchanged`
- [ ] Multiple seeds + confidence intervals for the headline numbers; ablation of history under degraded inputs
- [ ] Faster learning after a miss (protects repeat offenders like `unit_288` immediately); input-quality monitors (coverage age, edge drift)
- [ ] Scheduled full-suite audit runner (needed for the history signal in production)
- [ ] Finer handling of config and new-file changes (currently 0% / 3% saving)
