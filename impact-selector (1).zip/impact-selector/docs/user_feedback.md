# User / stakeholder validation

> **Status: protocol and instruments ready; sessions NOT yet run.** No real stakeholder feedback exists yet, and this file must not be presented as if it did. Fill in §4 after the sessions (target: 3 people, 30 min each), then delete this banner.

## 1. Who
| Role | Why | Sessions |
|---|---|---|
| Decision-maker (engineering manager / head of QA) | owns release risk and CI cost | 1 |
| QA / release engineer | decides what to skip today | 1 |
| Developer on the exam-core team | receives the RUN/SKIP list | 1 |

## 2. Session script (30 min)
1. (5 min) Current practice: "How do you decide today which tests to skip? Last time it went wrong?"
2. (10 min) Task-based: open the web app (`python app/server.py`) and, without help, answer:
   a. "You changed `core/timer.py`. Which tests run and why?" b. "A docs-only change – what runs?" c. "Pick one skipped test and tell me whether you trust the reason." d. "Here the banner says *degraded*. What do you do?"
3. (10 min) Show `results.md` (baseline vs selector, misses). Ask: "What miss rate would you accept? For which modules would you never skip?"
4. (5 min) SUS-lite (1–5): I'd use this weekly · The reasons were clear · I trust a skip · I'd want to override a skip · It fits how we ship.

## 3. Hypotheses to confirm or kill
H1 managers care more about *zero silent skips* than the percentage saved. H2 the per-test reason is what makes a skip acceptable. H3 a safe-list of never-skip modules (timer, submission, autosave) is wanted. H4 people want an override + "why did this fail after skip?" trace.

## 4. Findings (fill in after sessions)
| Participant | Task a/b/c/d success | Trust (1–5) | Accepted miss rate | Quotes | Requested change |
|---|---|---|---|---|---|
| P1 | | | | | |
| P2 | | | | | |
| P3 | | | | | |

**Changes made because of feedback:** _(to be completed)_
