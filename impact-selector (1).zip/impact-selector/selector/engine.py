"""Change-impact test selection with a per-test, human-readable rationale.

Modes (technical approaches compared in experiments):
  all         baseline 1: run everything
  name_match  baseline 2: run tests whose declared target file is literally a changed file
  graph       Approach A: reverse-dependency closure over the static import map
  coverage    Approach B: tests whose recorded coverage contains a changed file
  hybrid      Approach C (selected): union of graph + coverage + learned failure association,
              plus fail-safe guards. A test is skipped only if EVERY signal independently says skip.
"""
from dataclasses import dataclass, field

DOC_EXT = (".md", ".rst", ".txt")
CONFIG_EXT = (".yaml", ".yml", ".toml", ".env", ".ini", ".json")
MODES = ("all", "name_match", "graph", "coverage", "hybrid")


@dataclass
class Config:
    tau: float = 0.30          # min P(test fails | file changed) from history to force-run a test
    min_support: int = 3       # min past changes of a file before its history counts as evidence


@dataclass
class Decision:
    files: list
    mode: str
    rows: list = field(default_factory=list)   # {test, run, reasons, duration}
    notes: list = field(default_factory=list)  # change-level explanation
    degraded: bool = False
    known: list = field(default_factory=list)

    @property
    def selected(self):
        return {r["test"] for r in self.rows if r["run"]}

    def time(self, overhead=0.0):
        return overhead + sum(r["duration"] for r in self.rows if r["run"])

    def to_dict(self, overhead=0.0):
        full = sum(r["duration"] for r in self.rows) + overhead
        t = self.time(overhead)
        return {"files": self.files, "mode": self.mode, "notes": self.notes, "degraded": self.degraded,
                "run_count": len(self.selected), "skip_count": len(self.rows) - len(self.selected),
                "time_selected_s": round(t, 1), "time_full_s": round(full, 1),
                "time_saved_pct": round(100 * (1 - t / full), 1) if full else 0, "rows": self.rows}


class ImpactSelector:
    def __init__(self, graph, tests, store, cfg=None):
        self.graph, self.tests, self.store, self.cfg = graph, tests, store, cfg or Config()
        self.rev = {}
        for m, imps in graph.items():
            for i in imps:
                self.rev.setdefault(i, set()).add(m)

    def impacted(self, changed):
        seen, todo = set(changed), list(changed)
        while todo:
            for parent in self.rev.get(todo.pop(), ()):
                if parent not in seen:
                    seen.add(parent); todo.append(parent)
        return seen

    # ------------------------------------------------------------------
    def select(self, files, ast_unchanged=(), mode="hybrid"):
        assert mode in MODES, mode
        files = sorted(set(files))
        why = {t: [] for t in self.tests}
        dec = Decision(files, mode)
        nonunit = [t for t, v in self.tests.items() if v["type"] not in ("unit",)]

        if mode == "all":
            for t in why: why[t].append("BASELINE: run everything")
        elif mode == "name_match":
            for t, v in self.tests.items():
                hit = set(v["targets"]) & set(files)
                if hit: why[t].append(f"BASELINE: declared target {sorted(hit)[0]} was edited")
        else:
            for t, v in self.tests.items():
                if v["type"] == "smoke": why[t].append("GUARD: smoke tests always run")
            real = [f for f in files if not f.endswith(DOC_EXT) and f not in set(ast_unchanged)]
            cfgs = [f for f in real if f.endswith(CONFIG_EXT) or f.startswith("config/")]
            known = [f for f in real if f in self.graph]
            unknown = [f for f in real if f not in self.graph and f not in cfgs]
            if not files:
                dec.notes.append("empty change set -> smoke only")
            elif not real:
                dec.notes.append("no executable change (docs-only or AST-identical) -> smoke only; safe by construction")
            if cfgs:
                dec.notes.append(f"config change {cfgs}: behaviour of the whole platform can change -> run all")
                for t in why: why[t].append(f"GUARD: config file {cfgs[0]} changed")
            if unknown:
                dec.notes.append(f"file(s) {unknown} are not in the dependency map -> cannot bound impact; run every non-unit test")
                for t in nonunit: why[t].append(f"GUARD: unknown file {unknown[0]} (not in dependency map)")
            if known:
                self._signals(dec, why, known, mode)
            dec.known = known
        skip_msgs = self._skip_reasons(files, mode, why, dec)
        for t, v in self.tests.items():
            run = bool(why[t])
            dec.rows.append({"test": t, "type": v["type"], "run": run, "duration": v["duration"],
                             "reasons": why[t] if run else skip_msgs[t]})
        return dec

    # ------------------------------------------------------------------
    def _signals(self, dec, why, known, mode):
        imp = self.impacted(known)
        use_graph = mode in ("graph", "hybrid")
        use_cov = mode in ("coverage", "hybrid")
        use_hist = mode == "hybrid"
        health = self.store.health()
        if use_cov or use_hist:
            if health["degraded"]:
                dec.degraded = True
                dec.notes.append("event pipeline degraded (unfilled gap: %s) -> run all non-unit tests as a fail-safe" % list(health["gaps"]))
                for t, v in self.tests.items():
                    if v["type"] != "unit": why[t].append("GUARD: degraded evidence (coverage/history feed has a gap)")
        changes, cof = self.store.assoc()
        for t, v in self.tests.items():
            if use_graph:
                hit = sorted(set(v["targets"]) & imp)
                if hit:
                    direct = "directly edited" if hit[0] in known else "depends (transitively) on an edited file"
                    why[t].append(f"GRAPH: target {hit[0]} {direct}")
            if use_cov:
                cv = self.store.coverage.get(t)
                if cv is None:
                    why[t].append("COVERAGE: no coverage record (new/unmeasured test) -> cannot rule out")
                else:
                    hit = sorted(set(cv["modules"]) & set(known))
                    if hit: why[t].append(f"COVERAGE: v{cv['version']} shows it executes {hit[0]}")
            if use_hist:
                for f in known:
                    n = changes.get(f, 0)
                    c = cof.get(f, {}).get(t, 0)
                    if n >= self.cfg.min_support and c / n >= self.cfg.tau:
                        why[t].append(f"HISTORY: failed in {c} of last {n} changes to {f} ({c/n:.0%})")
                        break

    def _skip_reasons(self, files, mode, why, dec):
        out = {}
        changes, cof = self.store.assoc()
        real_known = dec.known
        for t, v in self.tests.items():
            if why[t]:
                continue
            r = []
            if mode == "all": pass
            elif mode == "name_match": r.append(f"declared target(s) {v['targets']} not among edited files")
            elif not real_known:
                r.append("; ".join(dec.notes) or "no executable change")
            else:
                if mode in ("graph", "hybrid"):
                    r.append(f"GRAPH: no import path from {real_known} to targets {v['targets']}")
                if mode in ("coverage", "hybrid"):
                    cv = self.store.coverage.get(t)
                    r.append(f"COVERAGE: v{cv['version']} ({len(cv['modules'])} modules) has none of the edited files")
                if mode == "hybrid":
                    best = max(((cof.get(f, {}).get(t, 0) / changes[f], f, changes[f]) for f in real_known if changes.get(f)),
                               default=None)
                    if best is None or all(changes.get(f, 0) < self.cfg.min_support for f in real_known):
                        r.append(f"HISTORY: too little history for {real_known} (< {self.cfg.min_support} past changes) - no evidence either way")
                    else:
                        r.append(f"HISTORY: max co-failure rate {best[0]:.1%} (via {best[1]}, n={best[2]}) < tau {self.cfg.tau:.0%}")
            out[t] = r
        return out
