"""Event-sourced state store: idempotent, order-insensitive, crash-recoverable.

Events: {event_id, stream, seq, type, payload}. Each producer stream numbers its events 0,1,2,...
Guarantees
  * duplicate event_id            -> ignored (idempotent)
  * out-of-order / delayed seq    -> buffered until the gap fills, then applied in stream order
  * competing writes              -> resolved by (version|revision, canonical-json) - commutative, so
                                     arrival order can never change the final state
  * lost event (permanent gap)    -> health() reports 'degraded' after `gap_tolerance` events; selector
                                     widens its selection (fail-safe); after `auto_skip` events the gap is
                                     skipped and RECORDED in state (never silent)
  * crash / torn write            -> recover() replays the append-only log, dropping a torn tail line
"""
import hashlib, json, os

CODE_CHANGES = ("logic", "refactor", "newfile")


class EventStore:
    def __init__(self, log_path=None, gap_tolerance=25, auto_skip=200):
        self.gap_tolerance, self.auto_skip = gap_tolerance, auto_skip
        self.coverage, self.outcomes, self.skipped = {}, {}, []
        self.seen, self.next_seq, self.buffer, self.gap_since = set(), {}, {}, {}
        self.clock = 0          # ingest counter (not part of state hash)
        self.version = 0
        self.counts = {"applied": 0, "duplicate": 0, "buffered": 0, "conflict": 0, "stale": 0}
        self._changes, self._cof, self._dirty = {}, {}, False
        self._log, self.log_path = None, log_path
        self._replaying = False
        if log_path:
            os.makedirs(os.path.dirname(log_path) or ".", exist_ok=True)
            self._log = open(log_path, "a")

    # ------------------------------------------------------------------ ingest
    def ingest(self, ev):
        self.clock += 1
        eid, s, q = ev["event_id"], ev["stream"], ev["seq"]
        if eid in self.seen:
            return self._count("duplicate")
        nxt = self.next_seq.get(s, 0)
        if q < nxt or (q in self.buffer.get(s, {})):
            return self._count("conflict")           # same seq, different id: reject, never overwrite
        self.seen.add(eid)
        self._append(ev)
        if q > nxt:
            self.buffer.setdefault(s, {})[q] = ev
            self.gap_since.setdefault(s, self.clock)
            if not self._replaying and self.clock - self.gap_since[s] > self.auto_skip:
                self.skip_gap(s, reason="auto")
            return self._count("buffered")
        self._apply(ev)
        self.next_seq[s] = nxt + 1
        self._drain(s)
        return self._count("applied")

    def _count(self, k):
        self.counts[k] += 1
        return k

    def _drain(self, s):
        buf = self.buffer.get(s, {})
        while self.next_seq[s] in buf:
            self._apply(buf.pop(self.next_seq[s]))
            self.next_seq[s] += 1
        if buf:
            self.gap_since[s] = self.clock
        else:
            self.gap_since.pop(s, None)

    def skip_gap(self, stream, reason="operator"):
        buf = self.buffer.get(stream)
        if not buf:
            return False
        lo = min(buf)
        self.skipped.append([stream, self.next_seq.get(stream, 0), lo])
        self._append({"type": "_skip_gap", "stream": stream, "reason": reason})
        self.next_seq[stream] = lo
        self._drain(stream)
        self.version += 1
        return True

    # ------------------------------------------------------------------ apply
    def _apply(self, ev):
        p = ev["payload"]
        key = lambda v, obj: (v, json.dumps(obj, sort_keys=True))
        if ev["type"] == "coverage":
            new = {"version": p["version"], "modules": sorted(p["modules"])}
            cur = self.coverage.get(p["test"])
            if cur is None or key(new["version"], new) > key(cur["version"], cur):
                self.coverage[p["test"]] = new
                self.version += 1
            else:
                self.counts["stale"] += 1
        elif ev["type"] == "outcome":
            new = {"files": sorted(p["files"]), "failed": sorted(p["failed"]),
                   "change_type": p["change_type"], "revision": p["revision"]}
            cur = self.outcomes.get(p["commit"])
            if cur is None:
                self.outcomes[p["commit"]] = new
                self._index(new)
                self.version += 1
            elif key(new["revision"], new) > key(cur["revision"], cur):
                self.outcomes[p["commit"]] = new
                self._dirty = True
                self.version += 1
            else:
                self.counts["stale"] += 1

    def _index(self, o):
        if o["change_type"] not in CODE_CHANGES:
            return
        for f in o["files"]:
            self._changes[f] = self._changes.get(f, 0) + 1
            for t in o["failed"]:
                d = self._cof.setdefault(f, {})
                d[t] = d.get(t, 0) + 1

    def assoc(self):
        """-> (changes[f], cofail[f][t]) built from past outcomes (rebuilt only after a revision)."""
        if self._dirty:
            self._changes, self._cof, self._dirty = {}, {}, False
            for o in self.outcomes.values():
                self._index(o)
        return self._changes, self._cof

    # ------------------------------------------------------------------ health / hash
    def health(self):
        gaps = {s: {"expected_seq": self.next_seq.get(s, 0), "buffered": len(b),
                    "age_events": self.clock - self.gap_since.get(s, self.clock)}
                for s, b in self.buffer.items() if b}
        degraded = any(g["age_events"] > self.gap_tolerance for g in gaps.values())
        return {"degraded": degraded, "gaps": gaps, "skipped_gaps": self.skipped, "counts": dict(self.counts)}

    def state_hash(self):
        blob = json.dumps({"coverage": self.coverage, "outcomes": self.outcomes,
                           "next_seq": self.next_seq, "skipped": self.skipped}, sort_keys=True)
        return hashlib.sha256(blob.encode()).hexdigest()[:16]

    # ------------------------------------------------------------------ durability
    def _append(self, ev):
        if self._log and not self._replaying:
            self._log.write(json.dumps(ev, sort_keys=True) + "\n")
            self._log.flush()

    @classmethod
    def recover(cls, log_path, **kw):
        """Rebuild state from the append-only log; drop a torn (partially written) final line."""
        good = []
        if os.path.exists(log_path):
            with open(log_path) as fh:
                for line in fh:
                    try:
                        good.append(json.loads(line))
                    except json.JSONDecodeError:
                        break                          # torn tail: everything after is untrusted
            with open(log_path, "w") as f:
                f.writelines(json.dumps(e, sort_keys=True) + "\n" for e in good)
        st = cls(None, **kw)
        st._replaying = True
        for e in good:
            if e.get("type") == "_skip_gap":
                st.skip_gap(e["stream"], reason="replay")
            else:
                st.ingest(e)
        st._replaying = False
        st.log_path, st._log = log_path, open(log_path, "a")
        return st
