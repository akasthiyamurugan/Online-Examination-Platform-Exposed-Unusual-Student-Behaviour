import json, os


class Dataset:
    def __init__(self, d="data"):
        self.dir = d
        L = lambda n: json.load(open(os.path.join(d, n)))
        self.graph = L("dependency_map.json")
        self.tests = {t["id"]: t for t in L("tests.json")}
        cov = L("coverage.json")
        self.cov_version, self.coverage = cov["version"], cov["tests"]
        self.commits = L("commits.json")
        gt = os.path.join(d, "ground_truth", "true_deps.json")
        self.truth = json.load(open(gt)) if os.path.exists(gt) else None

    @property
    def suite_time(self):
        return sum(t["duration"] for t in self.tests.values())


def coverage_events(ds, start_seq=0):
    return [dict(event_id=f"cov-init-{t}", stream="cov", seq=start_seq + i, type="coverage",
                 payload=dict(test=t, version=ds.cov_version, modules=m))
            for i, (t, m) in enumerate(sorted(ds.coverage.items()))]


def outcome_event(c, seq):
    return dict(event_id=f"ci-{c['id']}", stream="ci", seq=seq, type="outcome",
                payload=dict(commit=c["id"], files=c["files"], failed=c["failed"],
                             change_type=c["change_type"], revision=1))
