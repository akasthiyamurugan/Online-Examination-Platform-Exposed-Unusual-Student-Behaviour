"""CLI:  python -m selector.cli --files core/timer.py ui/exam_page.py [--mode hybrid] [--show-skipped] [--json]"""
import argparse, json, sys
from .bootstrap import build
from .engine import MODES
from .sim import OVERHEAD


def main(argv=None):
    ap = argparse.ArgumentParser(description="Change-impact test selector")
    ap.add_argument("--files", nargs="*", default=[], help="changed files")
    ap.add_argument("--ast-unchanged", nargs="*", default=[], help="changed files whose AST is identical (formatting only)")
    ap.add_argument("--mode", default="hybrid", choices=MODES)
    ap.add_argument("--data", default="data")
    ap.add_argument("--show-skipped", action="store_true")
    ap.add_argument("--json", action="store_true")
    a = ap.parse_args(argv)
    ds, store, sel = build(a.data)
    d = sel.select(a.files, a.ast_unchanged, a.mode).to_dict(OVERHEAD)
    if a.json:
        print(json.dumps(d, indent=1)); return
    print(f"Changed: {d['files']}   mode={d['mode']}")
    for n in d["notes"]: print("  note:", n)
    print(f"RUN {d['run_count']} / SKIP {d['skip_count']}   est. {d['time_selected_s']}s vs {d['time_full_s']}s full  (-{d['time_saved_pct']}%)")
    runs = [r for r in d["rows"] if r["run"]]
    for r in sorted(runs, key=lambda r: r["test"])[:25]:
        print(f"  RUN  {r['test']:<18} {r['reasons'][0]}")
    if len(runs) > 25: print(f"  ... {len(runs)-25} more RUN")
    if a.show_skipped:
        for r in [r for r in d["rows"] if not r["run"]][:15]:
            print(f"  SKIP {r['test']:<18} " + " | ".join(r["reasons"]))


if __name__ == "__main__":
    main()
