import os
from .data import Dataset, coverage_events, outcome_event
from .engine import ImpactSelector, Config
from .events import EventStore


def build(data_dir="data", history_upto=None, log_path=None, cfg=None):
    """Load the dataset, replay coverage + CI history into the event store, return (ds, store, selector)."""
    ds = Dataset(data_dir)
    st = EventStore.recover(log_path) if log_path and os.path.exists(log_path) and os.path.getsize(log_path) else EventStore(log_path)
    if not st.coverage:
        for e in coverage_events(ds): st.ingest(e)
        for i, c in enumerate(ds.commits[:history_upto]): st.ingest(outcome_event(c, i))
    return ds, st, ImpactSelector(ds.graph, ds.tests, st, cfg or Config())
