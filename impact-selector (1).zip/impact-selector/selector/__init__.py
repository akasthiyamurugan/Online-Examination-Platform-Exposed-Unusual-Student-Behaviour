"""Change-impact test selector with transparent skip rationale."""
