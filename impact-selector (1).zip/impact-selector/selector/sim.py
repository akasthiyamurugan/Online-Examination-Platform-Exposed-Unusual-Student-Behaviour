"""Replay of the CI history through the selector: baselines, ablations and fault injection."""
import random
from .data import coverage_events, outcome_event
from .engine import ImpactSelector, Config
from .events import EventStore

OVERHEAD = 30.0        # fixed per-run setup (provisioning, DB seed) - applies to every mode
REFRESH_EVERY, REFRESH_N = 50, 16   # nightly-style partial coverage refresh


class Channel:
    """Unreliable transport between CI and the selector: delay, reorder, duplicate, drop."""
    def __init__(self, rng, p_delay=.0, delay_max=0, p_dup=.0, p_drop=.0):
        self.rng, self.p_delay, self.delay_max, self.p_dup, self.p_drop = rng, p_delay, delay_max, p_dup, p_drop
        self.q = []          # (due, tiebreak, event)
        self.dropped = []

    def send(self, ev, t):
        if self.rng.random() < self.p_drop:
            self.dropped.append(ev["event_id"]); return
        d = self.rng.randint(1, self.delay_max) if self.rng.random() < self.p_delay else 0
        self.q.append((t + d, self.rng.random(), ev))
        if self.rng.random() < self.p_dup:
            self.q.append((t + d + self.rng.randint(0, max(1, self.delay_max)), self.rng.random(), ev))

    def deliver(self, t):
        due = sorted(x for x in self.q if x[0] <= t)
        self.q = [x for x in self.q if x[0] > t]
        return [e for _, _, e in due]

    def flush(self):
        return self.deliver(10 ** 9)


def perturb(ds, cov_drop=0.0, edge_drop=0.0, seed=1):
    """Return (graph, coverage_events) degraded on purpose to test robustness."""
    rng = random.Random(seed)
    g = {m: [d for d in imps if rng.random() >= edge_drop] for m, imps in ds.graph.items()}
    evs = coverage_events(ds)
    for e in evs:
        e["payload"]["modules"] = [m for m in e["payload"]["modules"] if rng.random() >= cov_drop]
    return g, evs


def simulate(ds, mode="hybrid", cfg=None, chaos=None, seed=7, graph=None, init_cov=None, refresh=True,
             store_kw=None, log_path=None):
    """Walk the commits in order. Before each commit the selector decides; afterwards the CI outcome
    (and periodic coverage refresh) flows back as events through an optionally faulty channel."""
    rng = random.Random(seed)
    store = EventStore(log_path, **(store_kw or {}))
    ch = Channel(random.Random(seed * 7919 + 1), **(chaos or {}))   # independent RNG: faults must not change payloads
    cseq = 0
    for e in (init_cov or coverage_events(ds)):
        store.ingest(e); cseq += 1
    sel = ImpactSelector(graph or ds.graph, ds.tests, store, cfg or Config())
    order = sorted(ds.tests, key=lambda t: (t in ds.coverage, t))     # unmeasured tests get refreshed first
    ptr, recs = 0, []
    for i, c in enumerate(ds.commits):
        for e in ch.deliver(i): store.ingest(e)
        dec = sel.select(c["files"], c["ast_unchanged"], mode)
        failed, chosen = set(c["failed"]), dec.selected
        recs.append(dict(idx=i, type=c["change_type"], time=dec.time(OVERHEAD), selected=len(chosen),
                         failed=len(failed), caught=len(failed & chosen), missed=sorted(failed - chosen),
                         degraded=dec.degraded, files=c["files"]))
        ch.send(outcome_event(c, i), i)
        if refresh and ds.truth and i % REFRESH_EVERY == 0:
            for _ in range(REFRESH_N):
                t = order[ptr % len(order)]; ptr += 1
                mods = [m for m in ds.truth["true_deps"][t] if rng.random() > .03]
                ch.send(dict(event_id=f"cov-r{i}-{t}", stream="cov", seq=cseq, type="coverage",
                             payload=dict(test=t, version=2 + i // REFRESH_EVERY, modules=mods)), i)
                cseq += 1
    for e in ch.flush(): store.ingest(e)
    return recs, store, ch


def summarise(recs, ds, lo=0, hi=None):
    r = recs[lo:hi]
    full = ds.suite_time + OVERHEAD
    tot = sum(x["time"] for x in r)
    F, C = sum(x["failed"] for x in r), sum(x["caught"] for x in r)
    return {"commits": len(r),
            "time_reduction_pct": round(100 * (1 - tot / (full * len(r))), 1),
            "avg_suite_s": round(tot / len(r), 1),
            "recall_pct": round(100 * C / F, 2) if F else 100.0,
            "missed_tests": F - C, "affected_tests": F,
            "commits_fully_safe_pct": round(100 * sum(1 for x in r if not x["missed"]) / len(r), 1),
            "avg_tests_run": round(sum(x["selected"] for x in r) / len(r), 1),
            "degraded_commits": sum(x["degraded"] for x in r)}
