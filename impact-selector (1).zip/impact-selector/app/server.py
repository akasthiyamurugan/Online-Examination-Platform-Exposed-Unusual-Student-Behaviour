"""Functional web app (stdlib only).   python app/server.py  ->  http://localhost:8000
GET  /                 UI
POST /api/select       {files, ast_unchanged, mode}   -> decision with per-test rationale
POST /api/events       {events:[...]}                 -> per-event status (applied/duplicate/buffered/conflict)
GET  /api/health       event-store health + state hash
GET  /api/meta         module list for the UI picker
"""
import json, os, sys
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")
sys.path.insert(0, ROOT)
from selector.bootstrap import build
from selector.sim import OVERHEAD

DS, STORE, SEL = build(os.path.join(ROOT, "data"), log_path=os.path.join(ROOT, "runtime", "events.jsonl"))


class H(BaseHTTPRequestHandler):
    def _send(self, code, body, ctype="application/json"):
        b = body if isinstance(body, bytes) else json.dumps(body).encode()
        self.send_response(code); self.send_header("Content-Type", ctype); self.send_header("Content-Length", str(len(b))); self.end_headers(); self.wfile.write(b)

    def do_GET(self):
        if self.path == "/":
            self._send(200, open(os.path.join(ROOT, "app", "static", "index.html"), "rb").read(), "text/html")
        elif self.path == "/api/health":
            self._send(200, dict(STORE.health(), state_hash=STORE.state_hash(), outcomes=len(STORE.outcomes), coverage_tests=len(STORE.coverage)))
        elif self.path == "/api/meta":
            self._send(200, {"modules": sorted(DS.graph), "tests": len(DS.tests)})
        else:
            self._send(404, {"error": "not found"})

    def do_POST(self):
        try:
            body = json.loads(self.rfile.read(int(self.headers.get("Content-Length", 0))) or b"{}")
            if self.path == "/api/select":
                d = SEL.select(body.get("files", []), body.get("ast_unchanged", []), body.get("mode", "hybrid"))
                self._send(200, d.to_dict(OVERHEAD))
            elif self.path == "/api/events":
                self._send(200, {"results": [STORE.ingest(e) for e in body["events"]], "health": STORE.health()})
            else:
                self._send(404, {"error": "not found"})
        except (KeyError, ValueError, AssertionError, json.JSONDecodeError) as e:
            self._send(400, {"error": f"bad request: {e}"})


if __name__ == "__main__":
    port = int(os.environ.get("PORT", 8000))
    print(f"Impact selector on http://localhost:{port}")
    ThreadingHTTPServer(("", port), H).serve_forever()
