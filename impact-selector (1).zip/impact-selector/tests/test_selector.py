import os, sys, unittest
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from selector.engine import ImpactSelector, Config
from selector.events import EventStore

TESTS = {
    "smoke_0": dict(type="smoke", targets=["a.py"], duration=1),
    "unit_a": dict(type="unit", targets=["a.py"], duration=1),
    "unit_b": dict(type="unit", targets=["b.py"], duration=1),
    "unit_c": dict(type="unit", targets=["c.py"], duration=1),
    "e2e_top": dict(type="e2e", targets=["top.py"], duration=50),
    "unit_hidden": dict(type="unit", targets=["c.py"], duration=1),   # secretly depends on a.py at runtime
    "new_test": dict(type="unit", targets=["c.py"], duration=1),      # no coverage yet
}
GRAPH = {"a.py": [], "b.py": ["a.py"], "c.py": [], "top.py": ["b.py"]}


def make():
    st = EventStore()
    for i, (t, m) in enumerate({"smoke_0": ["a.py"], "unit_a": ["a.py"], "unit_b": ["b.py", "a.py"], "unit_c": ["c.py"],
                                "e2e_top": ["top.py", "b.py", "a.py"], "unit_hidden": ["c.py", "a.py"]}.items()):
        st.ingest(dict(event_id=f"c{i}", stream="cov", seq=i, type="coverage", payload=dict(test=t, version=1, modules=m)))
    return st, ImpactSelector(GRAPH, TESTS, st, Config(tau=.3, min_support=3))


class TestSelector(unittest.TestCase):
    def test_transitive_and_hidden_edges_found(self):
        st, s = make(); d = s.select(["a.py"])
        self.assertTrue({"unit_a", "unit_b", "e2e_top", "unit_hidden", "smoke_0"} <= d.selected)   # hidden via coverage
        self.assertNotIn("unit_c", d.selected)

    def test_every_skip_has_reason_and_every_run_has_reason(self):
        st, s = make()
        for r in s.select(["a.py"]).rows: self.assertTrue(r["reasons"], r)
        for r in s.select(["c.py"]).rows: self.assertTrue(r["reasons"], r)

    def test_docs_only_runs_smoke_only(self):
        st, s = make(); self.assertEqual(s.select(["docs/x.md"]).selected, {"smoke_0"})

    def test_ast_identical_style_change_smoke_only(self):
        st, s = make(); self.assertEqual(s.select(["a.py"], ast_unchanged=["a.py"]).selected, {"smoke_0"})

    def test_unknown_file_runs_all_non_unit(self):
        st, s = make(); d = s.select(["brand_new.py"])
        self.assertIn("e2e_top", d.selected); self.assertNotIn("unit_c", d.selected - {"new_test"})

    def test_config_change_runs_everything(self):
        st, s = make(); self.assertEqual(s.select(["config/exam.yaml"]).selected, set(TESTS))

    def test_empty_change_set(self):
        st, s = make(); self.assertEqual(s.select([]).selected, {"smoke_0"})

    def test_unmeasured_test_is_never_skipped(self):
        st, s = make(); self.assertIn("new_test", s.select(["b.py"]).selected)

    def test_history_catches_edge_invisible_to_graph_and_coverage(self):
        st, s = make()                                     # unit_c fails 4 of 5 times when b.py changes
        for i in range(5):
            st.ingest(dict(event_id=f"o{i}", stream="ci", seq=i, type="outcome", payload=dict(
                commit=f"c{i}", files=["b.py"], failed=["unit_c"] if i < 4 else [], change_type="logic", revision=1)))
        d = s.select(["b.py"]); row = next(r for r in d.rows if r["test"] == "unit_c")
        self.assertTrue(row["run"]); self.assertTrue(row["reasons"][0].startswith("HISTORY"))
        self.assertNotIn("unit_c", ImpactSelector(GRAPH, TESTS, st, Config(tau=2.0)).select(["b.py"]).selected)

    def test_degraded_feed_widens_selection(self):
        st, s = make(); st.gap_tolerance = 2
        for i in range(3, 12):
            st.ingest(dict(event_id=f"g{i}", stream="ci", seq=i, type="outcome", payload=dict(
                commit=f"x{i}", files=["c.py"], failed=[], change_type="logic", revision=1)))
        d = s.select(["c.py"]); self.assertTrue(d.degraded); self.assertIn("e2e_top", d.selected)

    def test_baselines(self):
        st, s = make()
        self.assertEqual(s.select(["a.py"], mode="all").selected, set(TESTS))
        self.assertEqual(s.select(["a.py"], mode="name_match").selected, {"smoke_0", "unit_a"})


if __name__ == "__main__":
    unittest.main()
