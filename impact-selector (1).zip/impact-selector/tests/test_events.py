import json, os, random, sys, tempfile, unittest
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from selector.events import EventStore


def out(i, files=("core/timer.py",), failed=("t1",), rev=1, ct="logic"):
    return dict(event_id=f"ci-{i}-r{rev}", stream="ci", seq=i, type="outcome",
                payload=dict(commit=f"c{i}", files=list(files), failed=list(failed), change_type=ct, revision=rev))

def cov(i, test="t1", ver=1, mods=("a",), stream="cov"):
    return dict(event_id=f"cov-{test}-v{ver}-{i}", stream=stream, seq=i, type="coverage",
                payload=dict(test=test, version=ver, modules=list(mods)))


class TestEventFaults(unittest.TestCase):
    def stream(self, n=60):
        return [out(i, files=(f"m{i%5}.py",), failed=(f"t{i%7}",)) for i in range(n)]

    def clean_hash(self, evs):
        s = EventStore()
        for e in evs: s.ingest(e)
        return s.state_hash()

    def test_duplicates_are_idempotent(self):
        evs = self.stream(); ref = self.clean_hash(evs)
        s = EventStore()
        for e in evs:
            s.ingest(e); s.ingest(e); s.ingest(e)
        self.assertEqual(s.state_hash(), ref)
        self.assertEqual(s.counts["duplicate"], 2 * len(evs))

    def test_out_of_order_converges(self):
        evs = self.stream(); ref = self.clean_hash(evs)
        for seed in range(20):
            sh = evs[:]; random.Random(seed).shuffle(sh)
            s = EventStore()
            for e in sh: s.ingest(e)
            self.assertEqual(s.state_hash(), ref, f"seed {seed}")
            self.assertFalse(s.health()["gaps"])

    def test_delay_buffers_then_applies_and_never_partially_corrupts(self):
        evs = self.stream(10)
        s = EventStore()
        for e in evs[:3] + evs[4:]: s.ingest(e)          # seq 3 delayed
        self.assertEqual(len(s.outcomes), 3)              # nothing beyond the gap applied
        self.assertEqual(s.health()["gaps"]["ci"]["buffered"], 6)
        s.ingest(evs[3])                                  # late arrival heals
        self.assertEqual(len(s.outcomes), 10); self.assertEqual(s.state_hash(), self.clean_hash(evs))

    def test_stale_coverage_never_overwrites_newer(self):
        a, b = cov(0, ver=2, mods=("new",)), cov(1, ver=1, mods=("old",))
        for order in ([a, b], [b, a]):
            s = EventStore()
            for e in order: s.ingest(e)
            self.assertEqual(s.coverage["t1"]["modules"], ["new"])

    def test_conflicting_seq_rejected(self):
        s = EventStore(); s.ingest(out(0))
        evil = out(0); evil["event_id"] = "different-id"
        self.assertEqual(s.ingest(evil), "conflict")

    def test_revision_wins_regardless_of_arrival(self):
        r1, r2 = out(0, failed=("t1",), rev=1), out(1, failed=("t1", "t2"), rev=2); r2["payload"]["commit"] = "c0"
        h = []
        for order in ([r1, r2], [r2, r1]):
            s = EventStore()
            for e in order: s.ingest(e)
            h.append(s.state_hash()); self.assertEqual(s.outcomes["c0"]["failed"], ["t1", "t2"])
        self.assertEqual(h[0], h[1])

    def test_lost_event_degrades_then_auto_skip_is_recorded(self):
        s = EventStore(gap_tolerance=5, auto_skip=20)
        s.ingest(out(0))
        for i in range(2, 12): s.ingest(out(i))           # seq 1 lost forever
        self.assertTrue(s.health()["degraded"])
        for i in range(12, 40): s.ingest(out(i))
        self.assertFalse(s.health()["degraded"])
        self.assertEqual(s.skipped[0][:2], ["ci", 1])     # gap is on the record, not silent

    def test_torn_write_recovery(self):
        d = tempfile.mkdtemp(); p = os.path.join(d, "log.jsonl")
        s = EventStore(p)
        for e in self.stream(30): s.ingest(e)
        h = s.state_hash(); s._log.close()
        with open(p, "a") as f: f.write('{"event_id": "half-writ')
        r = EventStore.recover(p)
        self.assertEqual(r.state_hash(), h)
        r.ingest(out(30)); r._log.close()                 # log still usable after repair
        self.assertEqual(len(EventStore.recover(p).outcomes), 31)

    def test_recovery_reproduces_buffered_and_skipped_state(self):
        d = tempfile.mkdtemp(); p = os.path.join(d, "log.jsonl")
        s = EventStore(p, gap_tolerance=5, auto_skip=15)
        s.ingest(out(0))
        for i in range(2, 30): s.ingest(out(i))
        h = s.state_hash(); s._log.close()
        self.assertEqual(EventStore.recover(p, gap_tolerance=5, auto_skip=15).state_hash(), h)


if __name__ == "__main__":
    unittest.main()
