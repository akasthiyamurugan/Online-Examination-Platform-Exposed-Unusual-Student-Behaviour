#!/usr/bin/env python3
"""Synthetic-but-realistic data for an online exam platform.

Produces (all seeded, deterministic):
  data/dependency_map.json      module -> direct imports (6% of edges MISSING: dynamic imports)
  data/tests.json               test id, type, duration, static targets
  data/coverage.json            v1 coverage snapshot (8% entries stale/dropped, ~10% of tests unrecorded = new tests)
  data/commits.json             commits: files, change_type, ast_unchanged, failed tests (CI outcome)
  data/ground_truth/true_deps.json   full runtime dependencies incl. hidden edges (used ONLY by the simulator & error analysis)

Failure model (why tests fail after a change) is stated in docs/technical.md section 2.
"""
import argparse, json, os, random

LAYERS = [
    ("utils", "clock validators logging crypto storage i18n formatting ids retry_math serializer feature_flags metrics".split()),
    ("core", "timer session submission autosave grading question_bank randomizer auth access_control attempt_state deadline integrity".split()),
    ("net", "retry sync offline_queue heartbeat compression transport conflict_resolver backoff".split()),
    ("services", "exam_service scheduler notification result_service report roster upload session_service question_service analytics audit accommodations appeals invigilation export grading_service".split()),
    ("proctor", "focus_monitor tab_switch_detector idle_detector webcam_check paste_detector network_dropout_flag multi_login screen_share".split()),
    ("ui", "login_page exam_page question_view timer_widget submit_dialog offline_banner review_page results_page admin_dash roster_view upload_view accessibility keyboard_nav autosave_indicator calculator_widget help_widget".split()),
]
COMMIT_TYPES = [("logic", .45), ("refactor", .15), ("style", .10), ("docs", .15), ("config", .05), ("newfile", .10)]
P = {"logic": (.50, .22, .35), "refactor": (.12, .05, .08)}  # P(fail | direct target, transitive dep, hidden edge)


def wchoice(rng, pairs):
    r, acc = rng.random(), 0
    for k, w in pairs:
        acc += w
        if r <= acc:
            return k
    return pairs[-1][0]


def main(out="data", seed=42, n_tests=320, n_commits=2400):
    rng = random.Random(seed)
    mods_by_layer = {l: [f"{l}/{n}.py" for n in names] for l, names in LAYERS}
    all_mods = [m for l, _ in LAYERS for m in mods_by_layer[l]]

    true_imports = {}
    for i, (l, _) in enumerate(LAYERS):
        for m in mods_by_layer[l]:
            if i == 0:
                true_imports[m] = []
                continue
            prev = mods_by_layer[LAYERS[i - 1][0]]
            lower = [x for L, _ in LAYERS[:i] for x in mods_by_layer[L]]
            true_imports[m] = sorted(set(rng.sample(prev * 3 + lower, rng.randint(1, 4))))

    def closure(m, depth):
        seen, frontier = {m}, [m]
        for _ in range(depth):
            frontier = [d for x in frontier for d in true_imports[x] if d not in seen]
            seen.update(frontier)
        return seen

    dep_map = {m: [d for d in imps if rng.random() > .06] for m, imps in true_imports.items()}

    non_ui = [m for m in all_mods if not m.startswith("ui/")]
    tests = []
    smoke_targets = ["core/timer.py", "core/submission.py", "core/auth.py", "core/session.py", "ui/exam_page.py", "net/sync.py"]
    for i, tgt in enumerate(smoke_targets):
        tests.append(dict(id=f"smoke_{i:02d}", type="smoke", targets=[tgt], duration=round(rng.uniform(3, 10), 1)))
    kinds = [("unit", .58), ("integration", .22), ("e2e", .09), ("network_fault", .11)]
    for i in range(n_tests - len(tests)):
        k = wchoice(rng, kinds)
        if k == "unit":
            tg, dur = [rng.choice(non_ui)], rng.uniform(.3, 2)
        elif k == "integration":
            tg, dur = rng.sample(mods_by_layer["services"] + mods_by_layer["core"] + mods_by_layer["proctor"] + mods_by_layer["net"], rng.randint(2, 3)), rng.uniform(5, 25)
        elif k == "e2e":
            tg, dur = rng.sample(mods_by_layer["ui"], rng.randint(1, 2)) + rng.sample(mods_by_layer["services"], rng.randint(1, 2)), rng.uniform(40, 180)
        else:
            tg, dur = rng.sample(mods_by_layer["net"], rng.randint(1, 2)) + [rng.choice(mods_by_layer["core"])], rng.uniform(20, 90)
        tests.append(dict(id=f"{k}_{i:03d}", type=k, targets=sorted(set(tg)), duration=round(dur, 1)))

    true_deps, hidden = {}, {}
    for t in tests:
        depth = 1 if t["type"] == "unit" else 3
        deps = set().union(*(closure(m, depth) for m in t["targets"]))
        h = set()
        if t["type"] != "smoke" and rng.random() < .15:
            h = set(rng.sample(all_mods, rng.randint(1, 2))) - deps
        true_deps[t["id"]] = sorted(deps | h)
        hidden[t["id"]] = sorted(h)

    cov = {}
    for t in tests:
        if t["type"] != "smoke" and rng.random() < .10:
            continue
        cov[t["id"]] = [m for m in true_deps[t["id"]] if rng.random() > .08]

    order = all_mods[:]
    rng.shuffle(order)
    weights = [1 / (r + 1) ** .8 for r in range(len(order))]
    flaky = {t["id"] for t in tests if rng.random() < .06}
    commits = []
    for c in range(n_commits):
        ct = wchoice(rng, COMMIT_TYPES)
        if ct == "docs":
            files, ast_unchanged = [f"docs/{rng.choice(['guide','faq','readme','changelog'])}.md"], []
        elif ct == "config":
            files, ast_unchanged = ["config/exam.yaml"], []
        else:
            files = sorted(set(rng.choices(order, weights, k=rng.choices([1, 2, 3, 4], [50, 30, 14, 6])[0])))
            ast_unchanged = list(files) if ct == "style" else []
            if ct == "newfile":
                files = sorted(set(files[:rng.randint(0, 1)] + [f"services/new_feature_{c}.py"]))
        failed = set()
        for t in tests:
            tid, tg, td, hd = t["id"], set(t["targets"]), set(true_deps[t["id"]]), set(hidden[t["id"]])
            if ct in P:
                pd, pt, ph = P[ct]
                q = 1.0
                for f in files:
                    p = pd if f in tg else ph if f in hd else pt if f in td else 0
                    q *= (1 - p)
                if rng.random() > q:
                    failed.add(tid)
            elif ct == "config" and t["type"] in ("e2e", "network_fault", "integration"):
                if rng.random() < (.3 if t["type"] != "integration" else .1):
                    failed.add(tid)
            elif ct == "newfile":
                for f in files:
                    if f in true_imports and f in tg and rng.random() < .3:
                        failed.add(tid)
                if t["type"] not in ("unit", "smoke") and rng.random() < .012:
                    failed.add(tid)
        fl = sorted(t for t in sorted(flaky) if rng.random() < .02 and t not in failed)
        commits.append(dict(id=f"c{c:05d}", idx=c, files=files, change_type=ct, ast_unchanged=ast_unchanged,
                            failed=sorted(failed), flaky_failed=fl))

    os.makedirs(f"{out}/ground_truth", exist_ok=True)
    dump = lambda name, obj: json.dump(obj, open(f"{out}/{name}", "w"), indent=None, sort_keys=True)
    dump("dependency_map.json", dep_map)
    dump("tests.json", tests)
    dump("coverage.json", {"version": 1, "tests": cov})
    dump("commits.json", commits)
    dump("ground_truth/true_deps.json", {"true_deps": true_deps, "hidden": hidden, "true_imports": true_imports})
    nf = sum(len(c["failed"]) > 0 for c in commits)
    print(f"modules={len(all_mods)} tests={len(tests)} commits={n_commits} commits_with_failures={nf} "
          f"total_suite_time={sum(t['duration'] for t in tests):.0f}s tests_without_coverage={len(tests)-len(cov)}")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="data"); ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--tests", type=int, default=320); ap.add_argument("--commits", type=int, default=2400)
    a = ap.parse_args()
    main(a.out, a.seed, a.tests, a.commits)
